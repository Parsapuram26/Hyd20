package com.example.placement.service;

import java.util.List;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.placement.entity.Placement;
import com.example.placement.repository.PlacementRepository;

@Service
public  class PlacementServiceImpl implements PlacementService {
	@Autowired
	PlacementRepository pr1;

	@Override
	public Placement savePlacement(Placement placement) {
		// TODO Auto-generated method stub
		return pr1.save(placement);
	}

	@Override
	public List<Placement> fetchPlacementList() {
		// TODO Auto-generated method stub
		return pr1.findAll();
	}

	@Override
	public Placement fetchPlacementById(Long id) {
		// TODO Auto-generated method stub
		return pr1.findById(id).get();
	}

	@Override
	public void deletePlacementById(Long id) {
		// TODO Auto-generated method stub
		pr1.deleteById(id);
		
	}

	@Override
	public Placement updatePlacement(Long id, Placement placement) {
		// TODO Auto-generated method stub
		Placement depDB = pr1.findById(id).get();

	       if(Objects.nonNull(placement.getName()) &&
	       !"".equalsIgnoreCase(placement.getName())) {
	           depDB.setName(placement.getName());
	       }

	       if(Objects.nonNull(placement.getQualification()) &&
	               !"".equalsIgnoreCase(placement.getQualification())) {
	           depDB.setQualification(placement.getQualification());
	       }

	       if(Objects.nonNull(placement.getYear())) {
	           depDB.setYear(placement.getYear());
	       }

	       return pr1.save(depDB);
	}
	

}
