package com.example.placement.service;

import java.util.List;

import com.example.placement.entity.Placement;

public interface PlacementService {
	
	Placement savePlacement(Placement placement);

	public List<Placement> fetchPlacementList();
	public Placement fetchPlacementById(Long id);
	public void deletePlacementById(Long id);
	public Placement updatePlacement(Long id,Placement placement);

}
