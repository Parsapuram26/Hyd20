package com.example.placement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringyApplicationTests {

	@Test
	void contextLoads() {
	}

}
